# Expense-Manager
A simple expense tracker app to keep track of your daily expenses

### Screenshots

[![Home Page](https://s25.postimg.cc/ldito7gwf/create_Entry.png)](https://postimg.cc/image/ko01bugcr/)
[![daily_View](https://s25.postimg.cc/4prblqgzz/daily_View.png)](https://postimg.cc/image/ko01bvb7v/)
[![filter_View](https://s25.postimg.cc/pmnjqfpbj/filter_View.png)](https://postimg.cc/image/7jugz7tgr/)
[![statistics](https://s25.postimg.cc/cv9djy2ov/statistics.png)](https://postimg.cc/image/5s1i4bx97/)
